/**
 * Data Transfer Objects.
 */
package io.github.jhipster.registry.service.dto;
