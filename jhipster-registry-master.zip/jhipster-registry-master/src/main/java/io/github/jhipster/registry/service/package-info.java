/**
 * Service layer beans.
 */
package io.github.jhipster.registry.service;
