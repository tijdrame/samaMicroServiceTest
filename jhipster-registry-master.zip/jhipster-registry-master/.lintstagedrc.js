module.exports = {
  '{,src/**/}*.{md,json,ts,css,scss,yml}': ['prettier --write', 'git add']
};
